﻿using System;

namespace OWZX.Core
{
    /// <summary>
    /// 配置信息接口
    /// </summary>
    public interface IConfigInfo
    {
    }
}
