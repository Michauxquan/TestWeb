var langList = 
[
	{name:'zh-cn',	charset:'UTF-8'},
];
var skinList = 
[
	{name:'default',	charset:'UTF-8'},
];